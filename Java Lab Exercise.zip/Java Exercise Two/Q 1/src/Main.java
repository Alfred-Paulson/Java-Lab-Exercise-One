import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Enter the year: ");
        int year = input.nextInt();
        int LP = year/4; //(leap year)
        int days = 365*year+LP;
        int hours = days*24;
        int min = hours*60;
        System.out.println("There are "+LP+" leap years in "+ year+ " years");
        System.out.println("There are "+days+" days in "+ year+ " years");
        System.out.println("There are "+hours+" hours in "+ year+ " years");
        System.out.println("There are "+min+" minutes in "+ year+ " years");


    }
}