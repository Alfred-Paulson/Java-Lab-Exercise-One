public  class Main {
    public static void main(String[] args){
        int one = 1;
        int two = 2;
        int three = 3;
        int four = 4;
        int five = 5;
        int six = 6;

        int seven = 7;
        int eight = 8;
        int nine = 9;
        int a = 49;
        int b = 50;
        int c = 51;
        int d = 52;
        int e = 53;
        int f = 54;
        int g = 55;
        int h = 56;
        int i = 57;

        System.out.println("------------------");
        System.out.println("|  char  :  dec  |");
        System.out.println("------------------");
        System.out.println("|                |");
        System.out.println("|    "+one+" = "+a+"      |");
        System.out.println("|    "+two+" = "+b+"      |");
        System.out.println("|    "+three+" = "+c+"      |");
        System.out.println("|    "+four+" = "+d+"      |");
        System.out.println("|    "+five+" = "+e+"      |");
        System.out.println("|    "+six+" = "+f+"      |");
        System.out.println("|    "+seven+" = "+g+"      |");
        System.out.println("|    "+eight+" = "+h+"      |");
        System.out.println("|    "+nine+" = "+i+"      |");
        System.out.println("|                |");
        System.out.println("------------------");

    }
}