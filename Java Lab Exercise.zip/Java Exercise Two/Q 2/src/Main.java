import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the loan amount: ");
        int LoanAmount = input.nextInt();

        System.out.print("Enter the interest rate: ");
        float InterestRate = input.nextFloat();

        System.out.print("Enter the number of years: ");
        int years = input.nextInt();

        float TotalInterest = LoanAmount * InterestRate * years/100;
        float TotalLoan = LoanAmount+TotalInterest;

        System.out.println("The loan amount is :"+ LoanAmount);
        System.out.println("The interest rate is :"+ InterestRate+" %");
        System.out.println("The amount of years are : "+ years);
        System.out.println("The total amount for your loan is : "+ TotalLoan);



    }
}