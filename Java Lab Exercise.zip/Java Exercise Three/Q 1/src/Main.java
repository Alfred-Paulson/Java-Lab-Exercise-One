import  java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your Name:  ");
        String name =  input.next();

        System.out.print("Enter yor Age: ");
        int age = input.nextInt();

        System.out.println("Enter Date of Birth: ");
        System.out.print("Enter Day: ");
        int day = input.nextInt();
        System.out.print("Enter Month: ");
        int month = input.nextInt();
        System.out.print("Enter the Year:");
        int year = input.nextInt();


        System.out.println("Welcome "+name+" you were born in "+day+"/"+month+"/"+year+" and are "+age+" years old.");







    }
}