import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter two numbers: ");
        int x = input.nextInt();
        int y = input.nextInt();

        int sum = x+y;
        int product = x*y;
        int difference = x - y;

        System.out.println("Sum is "+sum);
        System.out.println("Product is "+ product);
        System.out.println("Difference is "+ difference);




    }
}