import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter miles traveled:  ");
        float distance = input.nextFloat();

        System.out.print("Enter time taken in hours: ");
        float hours = input.nextFloat();

        System.out.print("Enter petrol used in gallons: ");
        float petrol = input.nextFloat();

        float average_miles = Math.round(distance/hours);
        float average_gas = Math.round(distance/petrol);

        System.out.println("Average miles per hour : "+ average_miles);
        System.out.println("Average miles per gallon: "+ average_gas);

    }
}