import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the item: ");
        String item = input.next();

        System.out.print("Enter the price: ");
        double price = input.nextDouble();

        System.out.print("Enter the sale price: ");
        double sale_price = input.nextDouble();

        double difference = price- sale_price;
        double discount = Math.round((difference/price)*100);

        System.out.println(item+" is "+discount+"% off this week");




    }
}