import java.util.Scanner;

public class Main {

    /*
    *   1 assignment == 15
    *   2 assignment == 15
    *   3 assignment == 20
    *   4 assignment == 20
    *   5 assignment == 30
    *
    *   15  === 100
    *   grade === X
    *
    * */

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

         System.out.print("Enter your Assignment scores: ");
         int grade1 = input.nextInt();
         int grade2 = input.nextInt();
         int grade3 = input.nextInt();
         int grade4 = input.nextInt();
         int grade5 = input.nextInt();
         double a= (grade1*15.0)/100;
         double b= (grade2*15.0)/100;
         double c= (grade3*20.0)/100;
         double d= (grade4*20.0)/100;
         double e= (grade5*30.0)/100;

         double total = Math.round(a+b+c+d+e);
         System.out.println("Your total grade is: "+ total);



    }
}