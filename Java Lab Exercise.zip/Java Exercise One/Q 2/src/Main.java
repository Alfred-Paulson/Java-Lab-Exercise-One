public class Main {
    public static void main(String[] args)
    {
        double Celsius = 25.0;
        System.out.println("Celsius: "+ Celsius);
        double Fahrenheit = Celsius*(9.0/5.0)+32;
        System.out.print(Celsius );
        System.out.print("=" );
        System.out.print(Fahrenheit);




    }
}