public class Test {
    public static void main(String[] args) {
        double diameter = 7.0;
        double height = 10.5;
        double calc = (3.5)*(3.5)* (10.5) * (3.14) ;
        double volume = Math.round(calc);
        double calcu = 3.14*(3.5)*(2)*(10.5);
        double area = Math.round(calcu);
        System.out.print("The diameter of the can is ");
        System.out.print(diameter);
        System.out.println();
        System.out.print("The height of the can is ");
        System.out.print(height);
        System.out.println();
        System.out.print("The volume of the can is ");
        System.out.print(volume);
        System.out.println();
        System.out.print("The area of the cans label is ");
        System.out.print(area);

    }
}