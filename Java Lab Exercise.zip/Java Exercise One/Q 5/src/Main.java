import java.lang.Math;

public class Main {
    public static void main(String[] args) {
        double Ax =-5.5;
        double Ay =2;
        double Bx =-3;
        double By =-2.2;
        double Cx =1;
        double Cy =2;
        double Dx =7;
        double Dy =4.6;

        double distance1 = Math.sqrt(Math.pow((Bx - Ax), 2) + Math.pow((By - Ay), 2));
        double distance2 = Math.sqrt(Math.pow((Cx - Bx), 2) + Math.pow((Cy - By), 2));
        double distance3 = Math.sqrt(Math.pow((Dx - Cx), 2) + Math.pow((Dy - Cy), 2));
        System.out.println("Distance from "+Ax+","+Ay+ " to "+ Bx+","+By+ " is "+distance1);
        System.out.println("Distance from "+Bx+","+By+ " to "+ Cx+","+Cy+ " is "+distance2);
        System.out.println("Distance from "+Cx+","+Cy+ " to "+ Dx+","+Dy+ " is "+distance3);
        System.out.println();
        System.out.println(distance1);
        System.out.println(distance2);
        System.out.println(distance3);






    }
}