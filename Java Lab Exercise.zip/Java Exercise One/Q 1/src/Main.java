public class Main {
    public static void main(String[] args){
        double length =34.5;
        double width = 45.6;
        System.out.println("Length is:"+ length);
        System.out.println("Width is:"+ width);
        double perimeter =  2*(length+ width);
        System.out.println("The perimeter of the paper is:" + perimeter);



    }
}