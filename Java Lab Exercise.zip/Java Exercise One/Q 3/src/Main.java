public class Main {
    public static void main(String[] args) {
        double Fahrenheit = 121.0;
        System.out.println("Fahrenheit: "+ Fahrenheit);
        double Celsius =(Fahrenheit-32) /(9.0/5.0);
        System.out.print(Fahrenheit );
        System.out.print("=" );
        System.out.print(Celsius);

    }
}